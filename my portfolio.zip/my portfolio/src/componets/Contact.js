import React from 'react';

function Contact() {
  return (
    <section className="contact" id="contact">
      <div className="container">
        <h2>Contact Me</h2>
        <form>
          <input type="text" placeholder="Your Name" className="form-control" required />
          <input type="email" placeholder="Your Email" className="form-control" required />
          <textarea placeholder="Your Message" className="form-control" required></textarea>
          <button type="submit" className="btn btn-primary">Send Message</button>
        </form>
      </div>
    </section>
  );
}

export default Contact;
