import React from 'react';

function About() {
  return (
    <section className="about" id="about">
      <div className="container">
        <h2>About Me</h2>
        <p>Im Jairam, a developer with a passion for creating innovative solutions. I specialize in Python, Django, and front-end development.</p>
        <img src="/images/profile.jpg" alt="Profile" className="profile-img"/>
      </div>
    </section>
  );
}

export default About;
