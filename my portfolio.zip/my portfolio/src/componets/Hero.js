import React from 'react';

function Hero() {
  return (
    <section className="hero">
      <div className="container text-center">
        <h1>Hi, Im <span className="highlight">Jairam</span></h1>
        <p>A Passionate Developer</p>
        <a href="#projects" className="btn btn-primary">View My Work</a>
        <a href="#contact" className="btn btn-secondary">Contact Me</a>
      </div>
    </section>
  );
}

export default Hero;
