import React from 'react';

function Skills() {
  return (
    <section className="skills" id="skills">
      <div className="container">
        <h2>Skills</h2>
        <div className="skills-list d-flex justify-content-around">
          <div className="skill">Python</div>
          <div className="skill">Django</div>
          <div className="skill">HTML/CSS</div>
          <div className="skill">JavaScript</div>
          <div className="skill">SQL</div>
        </div>
      </div>
    </section>
  );
}

export default Skills;
