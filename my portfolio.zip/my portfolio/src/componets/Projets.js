import React from 'react';

function Projects() {
  return (
    <section className="projects" id="projects">
      <div className="container">
        <h2>Projects</h2>
        <div className="project">
          <img src="/images/project1.jpg" alt="Project 1"/>
          <h3>Project Name</h3>
          <p>Description of the project goes here.</p>
          <a href="#" className="btn btn-primary">View Project</a>
        </div>
        <div className="project">
          <img src="/images/project2.jpg" alt="Project 2"/>
          <h3>Project Name</h3>
          <p>Description of the project goes here.</p>
          <a href="#" className="btn btn-primary">View Project</a>
        </div>
      </div>
    </section>
  );
}

export default Projects;
