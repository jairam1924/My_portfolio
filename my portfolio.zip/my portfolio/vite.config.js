/*jshint esversion: 6*/ 
import { defineConfig } from 'vite';

export default defineConfig({
  root: './',
  build: {
    outDir: 'dist',
  },
  server: {
    port: 3000,
  },
  esbuild: {
    loader: 'jsx',  // Ensure this is correctly set if using JSX
    include: /\.jsx?$/,
  },
});
